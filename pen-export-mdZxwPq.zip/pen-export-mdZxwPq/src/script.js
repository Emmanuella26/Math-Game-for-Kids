let questions = [];
let currentQuestionIndex = 0;
let score = 0;

function generateQuestions() {
    for (let i = 0; i < 600; i++) {  // Changed to 600 questions
        let num1 = Math.floor(Math.random() * 5) + 1;
        let num2 = Math.floor(Math.random() * 5) + 1;
        let questionText = `${num1} + ${num2} = ?`;
        let answer = num1 + num2;
        let options = generateOptions(answer);
        questions.push({ questionText, answer, options });
    }
}

function generateOptions(correctAnswer) {
    let options = new Set();
    options.add(correctAnswer);
    while (options.size < 4) {
        options.add(Math.floor(Math.random() * 10) + 1);
    }
    return Array.from(options).sort(() => Math.random() - 0.5);
}

function showQuestion() {
    let questionElement = document.getElementById('question');
    let optionsElement = document.getElementById('options');
    let feedbackElement = document.getElementById('feedback');
    feedbackElement.innerHTML = '';

    let currentQuestion = questions[currentQuestionIndex];
    questionElement.innerHTML = currentQuestion.questionText;
    optionsElement.innerHTML = '';

    currentQuestion.options.forEach(option => {
        let button = document.createElement('button');
        button.innerHTML = option;
        button.className = 'option-btn';
        button.onclick = () => checkAnswer(option);
        optionsElement.appendChild(button);
    });
}

function checkAnswer(selectedOption) {
    let feedbackElement = document.getElementById('feedback');
    let finalScoreElement = document.getElementById('finalScore');

    if (selectedOption === questions[currentQuestionIndex].answer) {
        feedbackElement.innerHTML = 'Correct!';
        feedbackElement.style.color = 'green';
        score++;
        currentQuestionIndex++;
        if (currentQuestionIndex < questions.length) {
            showQuestion();
        } else {
            finalScoreElement.innerHTML = `Final Score: ${score}/600`;  // Adjusted final score display
            document.getElementById('options').style.display = 'none';
        }
    } else {
        feedbackElement.innerHTML = 'Try Again!';
        feedbackElement.style.color = 'red';
    }
}

generateQuestions();
showQuestion();
